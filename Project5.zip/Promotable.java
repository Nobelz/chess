/**
 * <p>Represents a piece that can be used as a promotion.</p>
 * <p>Marker interface.</p>
 *
 * @author Nobel Zhou (nxz157)
 * @version 1.0, 12/2/20
 */
public interface Promotable {
}